export const products = [
    {
        id: 'P001',
        name: 'Jordan One Take II PF',
        type: 'รองเท้าบาสเก็ตบอล',
        price: 2879,
        qtyInStock : 20
    },
    {
        id:'P002',
        name: 'Air Jordan 1 Hi FlyEase',
        type: 'รองเท้าเด็กโต',
        price: 3400,
        qtyInStock : 76
    },
    {
        id: 'P003',
        name: 'Jordan 6 Retro Little Flex',
        type: 'รองเท้าเด็กเล็ก',
        price: 2400,
        qtyInStock : 442
    },
    {
        id: 'P004',
        name: 'Air Jordan 6 Retro',
        type: 'รองเท้า',
        price: 6700,
        qtyInStock : 23
    },
    {
        id: 'P005',
        name: 'Air Jordan 1 Mid SE',
        type: 'รองเท้า',
        price: 3400,
        qtyInStock : 82
    },
    {
        id: 'P006',
        name: 'Air Jordan Retro 12',
        type: 'รองเท้า',
        price: 6700,
        qtyInStock : 43
    },
    {
        id: 'P007',
        name: 'Jordan Break',
        type: 'รองเท้าแตะแบบสวม',
        price: 1100,
        qtyInStock : 121
    },
    {
        id: 'P008',
        name: 'Air Jordan XXXV',
        type: 'รองเท้าบาสเก็ตบอล',
        price: 4879,
        qtyInStock : 32
    }
];
